Put your real files here:
- cv.pdf      -> your actual CV/resume (referenced by the Download CV buttons)
- profile.jpg -> optional headshot if you want to add a photo to the About section
